// Copyright Epic Games, Inc. All Rights Reserved.

#include "HW007GameMode.h"
#include "HW007Character.h"
#include "UObject/ConstructorHelpers.h"

AHW007GameMode::AHW007GameMode()
{

	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/BP_HWCharacter.BP_HWCharacter"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
}
