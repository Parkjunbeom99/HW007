// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HWMovementComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class HW007_API UHWMovementComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UHWMovementComponent();
	virtual void AddCharacterLocation(FVector2D MovementDir);
	virtual void AddCharacterZLocation(float Value);
	virtual void AddCharacterRotatation(FVector2D Rotator);
	virtual void AddCharacterRoll(float Value);


	
protected:

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	void GravityAcceleration(float DeltaTime);
	bool CheckOnGround();
	
protected:
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="MoveProperty")
	float MovementSpeed;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="RotateProperty")
	float RotateSpeed;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Gravity")
	uint8 bIsGravity :1;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Gravity")
	float GravityScale;

	bool IsOnGround;

	
};

