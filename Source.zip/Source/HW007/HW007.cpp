// Copyright Epic Games, Inc. All Rights Reserved.

#include "HW007.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, HW007, "HW007" );
 