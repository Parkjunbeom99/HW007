// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "HWCharacter.generated.h"

struct FInputActionValue;
class UInputAction;

UCLASS()
class HW007_API AHWCharacter : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	AHWCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
protected:
	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Components")
	TObjectPtr<class UCapsuleComponent>Trigger;
	
	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Components")
	TObjectPtr<class USkeletalMeshComponent>SkeletalMesh;

	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Components")
	TObjectPtr<class USpringArmComponent> SpringArm;

	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Components")
	TObjectPtr<class UCameraComponent> Camera;

	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Components")
	TObjectPtr<class UHWMovementComponent> MovementComp;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Input")
	TObjectPtr<class UInputMappingContext> DefaultMappingContext;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Input")
	TObjectPtr<UInputAction> MoveAction;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Input")
	TObjectPtr<UInputAction> LookAction;

	void Move(const FInputActionValue& Value);
	void Look(const FInputActionValue& Value);
};
