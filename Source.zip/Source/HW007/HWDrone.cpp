// Fill out your copyright notice in the Description page of Project Settings.


#include "HWDrone.h"

#include "EnhancedInputComponent.h"
#include "HWMovementComponent.h"

void AHWDrone::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (EnhancedInputComponent)
	{
		EnhancedInputComponent->BindAction(MoveZAction, ETriggerEvent::Triggered,this , &AHWDrone::MoveLocalZ);
		EnhancedInputComponent->BindAction(RotateRollAction, ETriggerEvent::Triggered,this , &AHWDrone::RotateRoll);
	}
}

void AHWDrone::MoveLocalZ(const FInputActionValue& Value)
{
	float ZValue = Value.Get<float>();
	MovementComp->AddCharacterZLocation(ZValue);
}
void AHWDrone::RotateRoll(const FInputActionValue& Value)
{
	float RollValue = Value.Get<float>();
	MovementComp->AddCharacterRoll(RollValue);
}


