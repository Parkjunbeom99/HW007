// Fill out your copyright notice in the Description page of Project Settings.


#include "HWMovementComponent.h"

// Sets default values for this component's properties
UHWMovementComponent::UHWMovementComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;
	RotateSpeed = 50.0f;
	MovementSpeed = 500.0f;
	bIsGravity = false;
	GravityScale = -98.0f;

	// ...
}




void UHWMovementComponent::TickComponent(float DeltaTime, enum ELevelTick TickType,
	FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (bIsGravity)
	{
		
		GravityAcceleration(DeltaTime);
	}
}

void UHWMovementComponent::GravityAcceleration(float DeltaTime)
{
	if (!CheckOnGround())
	{
		float Velocity = GravityScale * DeltaTime;
		GetOwner()->AddActorLocalOffset(FVector(0.f,0.f,Velocity));
		
	}
}
bool UHWMovementComponent::CheckOnGround()
{
	
	FVector Start = GetOwner()->GetActorLocation();
	float TraceDistance = 100.f; 
	FVector End = Start - FVector(0, 0, TraceDistance);

	FHitResult HitResult;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(GetOwner()); // 이거 자꾸 자기자신도 LAY되버려서 

	bool bHit = GetWorld()->LineTraceSingleByChannel(
		HitResult,
		Start,
		End,
		ECC_Visibility, 
		Params
	);
	
	DrawDebugLine(GetWorld(), Start, End, bHit ? FColor::Green : FColor::Red, false, 1.f);

	return bHit;
}


void UHWMovementComponent::AddCharacterLocation(FVector2D MovementDir)
{
	FVector2D MoveTo = MovementDir.GetSafeNormal() * MovementSpeed * GetWorld()->GetDeltaSeconds();
	if ( bIsGravity)
	{
		if (!CheckOnGround())
		{
			MoveTo *= 0.5f;
		
		}
		
	}
	GetOwner()->AddActorLocalOffset(FVector(MoveTo.X,MoveTo.Y,0.0f));
}


void UHWMovementComponent::AddCharacterRotatation(FVector2D Direction)
{
	
	if (!Direction.IsNearlyZero())
	{
		float DeltaTime = GetWorld()->GetDeltaSeconds();
		float Yaw = Direction.X * RotateSpeed * DeltaTime;
		float Pitch = Direction.Y * RotateSpeed * DeltaTime;
			
		GetOwner()->AddActorLocalRotation( FRotator(Pitch, Yaw, 0.0f));
	}	
	
}

void UHWMovementComponent::AddCharacterZLocation(float Value)
{
	GetOwner()->AddActorLocalOffset(FVector(0.0f,0.0f,Value* MovementSpeed * GetWorld()->GetDeltaSeconds() ));
}

void UHWMovementComponent::AddCharacterRoll(float Value)
{
	float Roll = Value * RotateSpeed * GetWorld()->GetDeltaSeconds();
	GetOwner()->AddActorLocalRotation( FRotator(0.0f, 0.0f, Roll));
}
