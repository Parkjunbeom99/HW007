// Fill out your copyright notice in the Description page of Project Settings.


#include "HWCharacter.h"

#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "HWMovementComponent.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/SpringArmComponent.h"

// Sets default values
AHWCharacter::AHWCharacter()
{
	Trigger = CreateDefaultSubobject<UCapsuleComponent>(TEXT("Trigger"));
	if (Trigger)
	{
		SetRootComponent(Trigger);
		Trigger->SetSimulatePhysics(false);
	}
	SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("SkeletalMesh"));
	if (SkeletalMesh)
	{
		SkeletalMesh->SetupAttachment(Trigger);
		SkeletalMesh->SetSimulatePhysics(false);
	}
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>SkeletaRef(TEXT("/Game/Characters/Mannequins/Meshes/SKM_Manny_Simple.SKM_Manny_Simple"));
	if (SkeletaRef.Succeeded())
	{
		SkeletalMesh->SetSkeletalMesh(SkeletaRef.Object);
	}
	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	if (SpringArm)
	{
		SpringArm->SetupAttachment(RootComponent);
		Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
		SpringArm->bUsePawnControlRotation = false;
		if (Camera)
		{
			Camera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);
			Camera->bUsePawnControlRotation = false; 
		}
		
	}
	MovementComp = CreateDefaultSubobject<UHWMovementComponent>(TEXT("MovementComp"));
	


}

// Called when the game starts or when spawned
void AHWCharacter::BeginPlay()
{
	Super::BeginPlay();
	APlayerController* PC = GetWorld()->GetFirstPlayerController();
	if (PC)
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer()))
		{
			Subsystem->AddMappingContext(DefaultMappingContext, 0);
		}
	}
	
}

// Called every frame
void AHWCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void AHWCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UEnhancedInputComponent* EnhancedInputComponent = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (EnhancedInputComponent)
	{
		EnhancedInputComponent->BindAction(MoveAction, ETriggerEvent::Triggered,this , &AHWCharacter::Move);
		EnhancedInputComponent->BindAction(LookAction, ETriggerEvent::Triggered,this , &AHWCharacter::Look);
	}
	

}

void AHWCharacter::Move(const FInputActionValue& Value)
{
	FVector2D MoveDir = Value.Get<FVector2D>();
	MovementComp->AddCharacterLocation(MoveDir);
	
}
void AHWCharacter::Look(const FInputActionValue& Value)
{
	FVector2D RotateDir = Value.Get<FVector2D>();
	MovementComp->AddCharacterRotatation(RotateDir);
}

