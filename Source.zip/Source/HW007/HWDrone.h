// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "HWCharacter.h"
#include "HWDrone.generated.h"

/**
 * 
 */
UCLASS()
class HW007_API AHWDrone : public AHWCharacter
{
	GENERATED_BODY()
protected:
	
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Input")
	TObjectPtr<UInputAction> MoveZAction;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Input")
	TObjectPtr<UInputAction> RotateRollAction;


	
	void MoveLocalZ(const FInputActionValue& Value);
	void RotateRoll(const FInputActionValue& Value);
	
};
